from django.urls import path 
from . import views 

urlpatterns = [
	path('', 			     views.index,  name="lista"),
	path('Create/', 		 views.Create, name="create_tarefa"),
	path('Read/<str:pk>/',   views.Read,   name="detalhes"),
	path('Update/<str:pk>/', views.Update, name="update_tarefa"),
	path('Delete/<str:pk>/', views.Delete, name="delete")	
]