from django.urls import path 
from . import views 

urlpatterns = [
	path('', 						views.index,         name="lista"),
	path('create_tarefa/', 			views.createTarefa,  name="create_tarefa"),
	path('details/<str:pk>/',       views.readTarefa,    name="detalhes"),
	path('update_tarefa/<str:pk>/', views.updateTarefa,  name="update_tarefa"),
	path('delete/<str:pk>/',        views.deleteTarefa,  name="delete")
	
	
]