from django.urls import path, include
from rest_framework import routers
from .views import TarefaViewSet


router = routers.DefaultRouter()
router.register("tarefas", TarefaViewSet)

app_name = "api"

urlpatterns = [
    path("", include(router.urls))
]
